import React, { useEffect, useMemo, useState } from "react";
import { createRoot } from "react-dom/client";
import {
  Plane, Hotel, MapPin, CalendarDays, CheckCircle2, Circle,
  Bell, Wallet, Search, Sparkles, Navigation, ExternalLink,
  Plus, Trash2, CloudSun, ArrowRight, Users, Clock, Umbrella,
  Stethoscope, Utensils, Luggage, RefreshCw
} from "lucide-react";
import "./styles.css";

const API_KEY = import.meta.env.VITE_GOOGLE_MAPS_API_KEY || "";

const interests = [
  ["beach", "🏖️ Beaches"], ["adventure", "🪂 Adventure"],
  ["nightlife", "🌃 Nightlife"], ["food", "🍴 Food"],
  ["culture", "🏛️ Culture"], ["history", "📚 History"],
  ["shopping", "🛍️ Shopping"], ["wellness", "🧘 Wellness"],
  ["dental", "🦷 Dental"], ["water", "🚤 Water sports"]
];

const seedTrip = {
  destination: "Albania",
  city: "Tirana",
  origin: "Manchester",
  startDate: "2026-09-25",
  endDate: "2026-09-28",
  travellers: 3,
  party: "friends",
  interests: ["beach", "adventure", "nightlife", "food", "dental"],
  flightBooked: false,
  accommodationBooked: false,
  airportTransfer: false
};

const seedChecklist = [
  ["passport", "Passport", "documents"],
  ["visa", "Visa / entry requirement", "documents"],
  ["flight", "Flight booked", "booking"],
  ["hotel", "Hotel / Airbnb booked", "booking"],
  ["transfer", "Airport transfer arranged", "transport"],
  ["insurance", "Travel insurance", "documents"],
  ["currency", "Currency / cash", "money"],
  ["cards", "Bank cards", "money"],
  ["clothes", "Weather-appropriate clothing", "packing"],
  ["charger", "Phone charger / adapter", "packing"],
  ["activities", "Activities booked", "activities"],
  ["checkin", "Online flight check-in", "flight"]
];

function load(key, fallback) {
  try { return JSON.parse(localStorage.getItem(key)) ?? fallback; } catch { return fallback; }
}

function save(key, value) {
  localStorage.setItem(key, JSON.stringify(value));
}

function googleFlightsUrl(trip) {
  const dates = `${trip.startDate.replaceAll("-", "")}-${trip.endDate.replaceAll("-", "")}`;
  return `https://www.google.com/travel/flights?q=Flights%20from%20${encodeURIComponent(trip.origin)}%20to%20${encodeURIComponent(trip.destination)}%20${dates}`;
}

async function geocode(city) {
  const url = `https://geocoding-api.open-meteo.com/v1/search?name=${encodeURIComponent(city)}&count=1&language=en&format=json`;
  const r = await fetch(url);
  if (!r.ok) throw new Error("Geocoding failed");
  const d = await r.json();
  if (!d.results?.length) throw new Error("Destination not found");
  return d.results[0];
}

async function weather(lat, lon) {
  const url = `https://api.open-meteo.com/v1/forecast?latitude=${lat}&longitude=${lon}&current=temperature_2m,weather_code,wind_speed_10m&daily=weather_code,temperature_2m_max,temperature_2m_min&forecast_days=7&timezone=auto`;
  const r = await fetch(url);
  if (!r.ok) throw new Error("Weather failed");
  return r.json();
}

async function currency(base, target) {
  const url = `https://api.frankfurter.app/latest?from=${encodeURIComponent(base)}&to=${encodeURIComponent(target)}`;
  const r = await fetch(url);
  if (!r.ok) throw new Error("Currency service failed");
  return r.json();
}

async function places(query) {
  if (!API_KEY) return [];
  const r = await fetch("https://places.googleapis.com/v1/places:searchText", {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      "X-Goog-Api-Key": API_KEY,
      "X-Goog-FieldMask": "places.id,places.displayName,places.formattedAddress,places.rating,places.userRatingCount,places.websiteUri,places.googleMapsUri,places.photos,places.priceLevel"
    },
    body: JSON.stringify({ textQuery: query })
  });
  if (!r.ok) throw new Error("Google Places failed");
  return (await r.json()).places || [];
}

function mapsSearchUrl(query) {
  return `https://www.google.com/maps/search/?api=1&query=${encodeURIComponent(query)}`;
}

function buildItinerary(trip) {
  const has = x => trip.interests.includes(x);
  const days = [
    {
      date: trip.startDate,
      title: "Arrival & Tirana",
      items: [
        ["10:00", "Breakfast & settle in", "food"],
        ["11:30", "Skanderbeg Square & central Tirana", "culture"],
        ["13:30", "Lunch", "food"],
        ...(has("dental") ? [["15:00", "Dental consultation / appointment", "dental"]] : []),
        ["17:30", "Pyramid of Tirana", "culture"],
        ["20:00", "Dinner", "food"],
        ...(has("nightlife") ? [["22:00", "Tirana nightlife", "nightlife"]] : [])
      ]
    },
    {
      date: new Date(new Date(trip.startDate).getTime() + 86400000).toISOString().slice(0,10),
      title: "Beach & Adventure",
      items: [
        ["08:30", "Breakfast", "food"],
        ["09:30", "Travel to Durrës", "transport"],
        ["10:30", "Durrës beach", "beach"],
        ...(has("adventure") || has("water") ? [["12:00", "Parasailing / water sports", "adventure"]] : []),
        ["14:00", "Seafood lunch", "food"],
        ["15:30", "Boat cruise", "water"],
        ["18:30", "Beach sunset", "beach"],
        ...(has("nightlife") ? [["21:00", "Dinner & evening out", "nightlife"]] : [])
      ]
    },
    {
      date: new Date(new Date(trip.startDate).getTime() + 2*86400000).toISOString().slice(0,10),
      title: "Culture, Food & Flexible Time",
      items: [
        ["09:00", "Breakfast", "food"],
        ["10:00", "Bunk'Art 2", "history"],
        ["12:30", "Lunch", "food"],
        ["14:00", has("shopping") ? "Shopping in central Tirana" : "Free time / café hopping", "shopping"],
        ["17:00", "Return to accommodation & pack", "packing"],
        ["19:00", "Final dinner", "food"]
      ]
    }
  ];
  return days;
}

function App() {
  const [trip, setTrip] = useState(() => load("journey_trip", seedTrip));
  const [checklist, setChecklist] = useState(() => load("journey_checklist", seedChecklist.map(([id,label]) => ({id,label,done:false}))));
  const [itinerary, setItinerary] = useState(() => load("journey_itinerary", buildItinerary(seedTrip)));
  const [weatherData, setWeatherData] = useState(null);
  const [fx, setFx] = useState(null);
  const [placesData, setPlacesData] = useState([]);
  const [query, setQuery] = useState("");
  const [active, setActive] = useState("overview");
  const [loading, setLoading] = useState(false);
  const [notice, setNotice] = useState("");

  useEffect(() => save("journey_trip", trip), [trip]);
  useEffect(() => save("journey_checklist", checklist), [checklist]);
  useEffect(() => save("journey_itinerary", itinerary), [itinerary]);

  useEffect(() => {
    (async () => {
      try {
        setLoading(true);
        const geo = await geocode(trip.city || trip.destination);
        const w = await weather(geo.latitude, geo.longitude);
        setWeatherData({ geo, ...w });
        const c = await currency("GBP", "ALL");
        setFx(c);
      } catch (e) {
        setNotice(e.message);
      } finally { setLoading(false); }
    })();
  }, [trip.city, trip.destination]);

  const ready = Math.round(checklist.filter(x => x.done).length / checklist.length * 100);

  const searchPlaces = async (q) => {
    setQuery(q);
    if (!API_KEY) {
      setNotice("Add VITE_GOOGLE_MAPS_API_KEY to enable live Google Places recommendations.");
      return;
    }
    try {
      setLoading(true);
      setPlacesData(await places(`${q} in ${trip.city}, ${trip.destination}`));
    } catch (e) { setNotice(e.message); }
    finally { setLoading(false); }
  };

  const toggle = id => setChecklist(c => c.map(x => x.id === id ? {...x, done: !x.done} : x));

  const regenerate = () => {
    setItinerary(buildItinerary(trip));
    setNotice("Itinerary regenerated from your current preferences.");
  };

  const addChecklist = () => {
    const label = prompt("What do you need to remember?");
    if (label?.trim()) setChecklist(c => [...c, {id: crypto.randomUUID(), label: label.trim(), done:false}]);
  };

  const searchCards = useMemo(() => {
    const qs = [];
    if (trip.interests.includes("dental")) qs.push("Dental clinics");
    if (trip.interests.includes("beach")) qs.push("Beaches");
    if (trip.interests.includes("water")) qs.push("Boat cruises");
    qs.push("Top tourist attractions");
    return qs;
  }, [trip.interests, trip.city]);

  return (
    <div className="app">
      <header className="topbar">
        <div className="brand"><Sparkles size={22}/> JourneyAI</div>
        <div className="top-actions">
          <button className="icon-btn" onClick={() => setNotice("Notification centre: reminders are generated from your trip dates.")}><Bell size={19}/></button>
          <button className="profile">T</button>
        </div>
      </header>

      <div className="shell">
        <aside className="sidebar">
          <button className={active==="overview"?"nav active":"nav"} onClick={()=>setActive("overview")}><Sparkles/> Overview</button>
          <button className={active==="itinerary"?"nav active":"nav"} onClick={()=>setActive("itinerary")}><CalendarDays/> Itinerary</button>
          <button className={active==="discover"?"nav active":"nav"} onClick={()=>setActive("discover")}><Search/> Discover</button>
          <button className={active==="checklist"?"nav active":"nav"} onClick={()=>setActive("checklist")}><CheckCircle2/> Checklist</button>
          <button className={active==="trip"?"nav active":"nav"} onClick={()=>setActive("trip")}><Luggage/> Trip setup</button>
        </aside>

        <main className="content">
          <section className="hero">
            <div>
              <div className="eyebrow">UPCOMING TRIP</div>
              <h1>🇦🇱 {trip.destination}</h1>
              <p>{trip.startDate} → {trip.endDate} · {trip.travellers} travellers · {trip.party}</p>
            </div>
            <div className="readiness">
              <div className="readiness-num">{ready}%</div>
              <span>trip readiness</span>
              <div className="progress"><span style={{width:`${ready}%`}}/></div>
            </div>
          </section>

          {notice && <div className="notice">{notice}<button onClick={()=>setNotice("")}>×</button></div>}

          {active === "overview" && <>
            <div className="grid four">
              <Metric icon={<Plane/>} title="Flight" value={trip.flightBooked ? "Booked" : "Needs booking"} action={!trip.flightBooked ? <a href={googleFlightsUrl(trip)} target="_blank">Find flights <ExternalLink size={13}/></a> : null}/>
              <Metric icon={<Hotel/>} title="Accommodation" value={trip.accommodationBooked ? "Booked" : "Needs booking"} action={<button onClick={()=>setActive("discover")}>Explore</button>}/>
              <Metric icon={<Navigation/>} title="Airport transfer" value={trip.airportTransfer ? "Arranged" : "Needs arranging"} action={<button onClick={()=>setActive("checklist")}>Review</button>}/>
              <Metric icon={<Wallet/>} title="Currency" value={fx ? `£1 ≈ ${fx.rates?.ALL?.toFixed(0)} ALL` : "Loading"} action={fx ? "Live rate" : "Loading…"}/>
            </div>

            <div className="grid two">
              <Card title="Next actions" icon={<CheckCircle2/>}>
                <Action text={!trip.flightBooked ? "Book your flight" : "Flight confirmed"} done={trip.flightBooked} onClick={()=>window.open(googleFlightsUrl(trip), "_blank")}/>
                <Action text={!trip.accommodationBooked ? "Choose hotel / Airbnb" : "Accommodation confirmed"} done={trip.accommodationBooked} onClick={()=>setActive("discover")}/>
                <Action text={!trip.airportTransfer ? "Arrange airport transfer" : "Airport transfer arranged"} done={trip.airportTransfer} onClick={()=>toggle("transfer")}/>
                <Action text="Check passport / entry requirements" done={checklist.find(x=>x.id==="visa")?.done} onClick={()=>setActive("checklist")}/>
                <Action text="Complete online check-in 24h before flight" done={checklist.find(x=>x.id==="checkin")?.done} onClick={()=>setActive("checklist")}/>
              </Card>

              <Card title="Weather & travel briefing" icon={<CloudSun/>}>
                {weatherData ? <div className="weather">
                  <div className="weather-main"><span>{Math.round(weatherData.current.temperature_2m)}°C</span><small>current</small></div>
                  <div><b>{weatherData.geo.name}</b><p>Forecast loaded for your destination. Check again closer to departure for the most reliable forecast.</p></div>
                </div> : <div className="loading"><RefreshCw className="spin"/> Loading destination data…</div>}
                <div className="tip"><Umbrella size={17}/><span><b>Travel tip:</b> Carry some local currency for small purchases and arrange your late-night airport transfer before departure.</span></div>
              </Card>
            </div>

            <Card title="Your AI itinerary" icon={<Sparkles/>} action={<button className="secondary" onClick={regenerate}>Regenerate</button>}>
              {itinerary.map((day, i)=><div className="day-preview" key={day.date}>
                <div className="day-title"><span>DAY {i+1}</span><b>{day.title}</b><small>{day.date}</small></div>
                <div className="timeline compact">
                  {day.items.slice(0,4).map(([time,title])=><div className="timeline-row" key={time+title}><span>{time}</span><b>{title}</b></div>)}
                  {day.items.length>4 && <button className="text-btn" onClick={()=>setActive("itinerary")}>View full day <ArrowRight size={14}/></button>}
                </div>
              </div>)}
            </Card>
          </>}

          {active === "itinerary" && <Card title="Day-by-day itinerary" icon={<CalendarDays/>} action={<button className="secondary" onClick={regenerate}><RefreshCw size={14}/> Regenerate</button>}>
            {itinerary.map((day, i)=><div className="itinerary-day" key={day.date}>
              <div className="day-heading"><div><span>DAY {i+1}</span><h2>{day.title}</h2></div><small>{day.date}</small></div>
              <div className="timeline">
                {day.items.map(([time,title,tag])=><div className="timeline-row" key={time+title}><span>{time}</span><div><b>{title}</b><small>{tag}</small></div></div>)}
              </div>
            </div>)}
          </Card>}

          {active === "discover" && <div>
            <div className="section-head"><div><h2>Discover</h2><p>Recommendations tailored to {trip.destination} and your interests.</p></div></div>
            <div className="chips">{searchCards.map(q=><button className="chip" onClick={()=>searchPlaces(q)} key={q}>{q}</button>)}</div>
            <div className="searchbox"><Search/><input value={query} onChange={e=>setQuery(e.target.value)} onKeyDown={e=>e.key==="Enter"&&searchPlaces(query)} placeholder={`Search places in ${trip.city}…`}/><button onClick={()=>searchPlaces(query)}>Search</button></div>
            {!API_KEY && <div className="api-help"><Stethoscope/><div><b>Enable live place recommendations</b><p>Add a restricted Google Places API key as <code>VITE_GOOGLE_MAPS_API_KEY</code>. The MVP will then return ratings, reviews, photos, websites, addresses and Maps links.</p></div></div>}
            <div className="place-grid">
              {placesData.map(p=><PlaceCard p={p} key={p.id}/>)}
            </div>
            {API_KEY && !placesData.length && <div className="empty">Choose a category above or search for a place.</div>}
          </div>}

          {active === "checklist" && <Card title="Travel checklist" icon={<CheckCircle2/>} action={<button className="secondary" onClick={addChecklist}><Plus size={14}/> Add item</button>}>
            <div className="checklist">
              {checklist.map(x=><div className={x.done?"check done":"check"} key={x.id} onClick={()=>toggle(x.id)}>
                {x.done ? <CheckCircle2/> : <Circle/>}<span>{x.label}</span>
                {["passport","visa","flight","hotel","transfer"].includes(x.id) && <small>essential</small>}
              </div>)}
            </div>
          </Card>}

          {active === "trip" && <TripSetup trip={trip} setTrip={setTrip} setItinerary={setItinerary}/>}
        </main>
      </div>
      <footer>JourneyAI MVP · Data from Open-Meteo, Frankfurter and optional Google Places · Booking links open external providers.</footer>
    </div>
  );
}

function Metric({icon,title,value,action}) {
  return <div className="metric"><div className="metric-icon">{icon}</div><div><span>{title}</span><b>{value}</b>{action && <div className="metric-action">{action}</div>}</div></div>
}

function Card({title,icon,action,children}) {
  return <section className="card"><div className="card-head"><h2>{icon}{title}</h2>{action}</div>{children}</section>
}

function Action({text,done,onClick}) {
  return <button className="action" onClick={onClick}>{done?<CheckCircle2 className="ok"/>:<Circle/>}<span>{text}</span><ArrowRight size={15}/></button>
}

function PlaceCard({p}) {
  const name = p.displayName?.text || "Place";
  const photo = p.photos?.[0];
  const photoUrl = photo && API_KEY ? `https://places.googleapis.com/v1/${photo.name}/media?maxWidthPx=800&key=${API_KEY}` : null;
  return <article className="place">
    {photoUrl ? <img src={photoUrl} alt={name}/> : <div className="place-img"><MapPin size={30}/></div>}
    <div className="place-body">
      <h3>{name}</h3>
      <div className="rating">★ {p.rating ?? "—"} <span>({p.userRatingCount ?? 0})</span></div>
      <p>{p.formattedAddress}</p>
      <div className="place-links">
        {p.websiteUri && <a href={p.websiteUri} target="_blank">Website <ExternalLink size={12}/></a>}
        <a href={p.googleMapsUri || mapsSearchUrl(name)} target="_blank">Maps <MapPin size={12}/></a>
      </div>
    </div>
  </article>
}

function TripSetup({trip,setTrip,setItinerary}) {
  const update = (key,value) => setTrip(t=>({...t,[key]:value}));
  const toggleInterest = id => setTrip(t=>({...t,interests:t.interests.includes(id)?t.interests.filter(x=>x!==id):[...t.interests,id]}));
  return <div className="setup">
    <Card title="Trip setup" icon={<Users/>}>
      <div className="form-grid">
        <label>Destination<input value={trip.destination} onChange={e=>update("destination",e.target.value)}/></label>
        <label>City<input value={trip.city} onChange={e=>update("city",e.target.value)}/></label>
        <label>Travelling from<input value={trip.origin} onChange={e=>update("origin",e.target.value)}/></label>
        <label>Travellers<input type="number" min="1" value={trip.travellers} onChange={e=>update("travellers",Number(e.target.value))}/></label>
        <label>Start date<input type="date" value={trip.startDate} onChange={e=>update("startDate",e.target.value)}/></label>
        <label>End date<input type="date" value={trip.endDate} onChange={e=>update("endDate",e.target.value)}/></label>
      </div>
      <label>Travelling party<select value={trip.party} onChange={e=>update("party",e.target.value)}><option value="solo">Solo</option><option value="couple">Couple</option><option value="friends">Friends</option><option value="family">Family</option></select></label>
      <h3>Interests</h3>
      <div className="chips">{interests.map(([id,label])=><button key={id} className={trip.interests.includes(id)?"chip selected":"chip"} onClick={()=>toggleInterest(id)}>{label}</button>)}</div>
      <div className="toggles">
        <label><input type="checkbox" checked={trip.flightBooked} onChange={e=>update("flightBooked",e.target.checked)}/> Flight already booked</label>
        <label><input type="checkbox" checked={trip.accommodationBooked} onChange={e=>update("accommodationBooked",e.target.checked)}/> Accommodation already booked</label>
        <label><input type="checkbox" checked={trip.airportTransfer} onChange={e=>update("airportTransfer",e.target.checked)}/> Airport transfer arranged</label>
      </div>
      <button className="primary" onClick={()=>setItinerary(buildItinerary(trip))}><Sparkles size={16}/> Generate itinerary</button>
    </Card>
  </div>
}

createRoot(document.getElementById("root")).render(<App />);
