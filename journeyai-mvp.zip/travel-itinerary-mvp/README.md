# JourneyAI Travel Itinerary MVP

A responsive React/Vite PWA prototype for the end-to-end travel itinerary concept.

## Included
- Trip setup: destination, dates, origin, travellers, party and interests
- AI-style day-by-day itinerary generator (deterministic MVP rules)
- Flight discovery handoff to Google Flights
- Accommodation/experience discovery shell
- Google Places (New) integration when `VITE_GOOGLE_MAPS_API_KEY` is supplied
- Live weather using Open-Meteo
- Live GBP -> ALL exchange rate using Frankfurter
- Travel readiness checklist with local persistence
- Responsive web/mobile UI
- Trip data persisted in localStorage
- Places cards can show rating, review count, photos, website and Google Maps link when Google Places is enabled

## Run

```bash
npm install
cp .env.example .env
npm run dev
```

Then open the Vite URL.

## Google Places setup

1. Create a Google Cloud project.
2. Enable Places API (New).
3. Create a browser-restricted API key.
4. Set `VITE_GOOGLE_MAPS_API_KEY` in `.env`.
5. Restrict the key to your development/production web origins.

Do NOT use an unrestricted key.

## MVP API choices

- Open-Meteo: geocoding + weather, no API key for the MVP.
- Frankfurter: exchange rates, no API key for the MVP.
- Google Places API (New): live place data, ratings, reviews, photos, website and Maps links; requires a Google Maps Platform key.
- Google Flights: external search/booking handoff; this MVP does not claim direct booking access.

## What is intentionally mocked
- True LLM itinerary generation
- Live flight status
- Airline online check-in deep links
- Hotel/Airbnb inventory and booking
- Activity booking
- Push notifications
- Authentication/backend
- Group collaboration
- Email booking ingestion

These should be added behind a backend in the next iteration.

## Important production notes
Google Places data has attribution and caching/display requirements. Follow the Google Maps Platform policies before launching. The MVP currently keeps data client-side and is intended as a prototype.
